// MMP 100 - P5.js Geometric Scene
// Subject: a house with a sun
// Background: sky and grass

// Custom variable
var sunSize = 80;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  // --- BACKGROUND ---

  // Sky (light blue rectangle)
  background(135, 206, 235);

  // Clouds (white circles)
  fill(255, 255, 255);
  noStroke();
  ellipse(80, 70, 60, 40);
  ellipse(110, 60, 50, 35);
  ellipse(55, 65, 40, 30);

  ellipse(290, 90, 55, 35);
  ellipse(320, 80, 45, 30);
  ellipse(268, 85, 35, 25);

  // Grass (green rectangle)
  fill(100, 180, 80);
  rect(0, 280, 400, 120);

  // --- SUN ---
  fill(255, 220, 0);
  noStroke();
  ellipse(320, 80, sunSize, sunSize);

  // --- SUBJECT: HOUSE ---

  // House body (brown rectangle)
  fill(180, 120, 60);
  rect(130, 220, 140, 100);

  // Roof (dark red triangle)
  fill(160, 50, 50);
  triangle(110, 220, 200, 130, 290, 220);

  // Door (dark rectangle)
  fill(100, 60, 30);
  rect(178, 270, 44, 50);

  // Door knob (small circle)
  fill(255, 200, 0);
  ellipse(215, 297, 8, 8);

  // Window left (light blue square)
  fill(180, 220, 255);
  rect(140, 235, 40, 35);

  // Window right (light blue square)
  fill(180, 220, 255);
  rect(220, 235, 40, 35);

  // Window cross lines
  stroke(150);
  strokeWeight(1.5);
  line(160, 235, 160, 270); // vertical
  line(140, 252, 180, 252); // horizontal
  line(240, 235, 240, 270);
  line(220, 252, 260, 252);
  noStroke();

  // --- INTERACTIVITY ---
  // Sun grows when mouse is pressed
  if (mouseIsPressed) {
    sunSize = 110;
  } else {
    sunSize = 80;
  }
}
